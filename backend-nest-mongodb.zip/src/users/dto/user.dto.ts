export class UserAuthen {
    userId?: number;
    username: string;
    password: string;
}

export class UserAuthenResponse {
    userId?: number;
    username: string;
}