import { Injectable } from '@nestjs/common';
import { UserAuthen } from './dto/user.dto';

@Injectable()
export class UsersService {
    private readonly users: UserAuthen[] = [
        {
            userId: 1,
            username: 'admin',
            password: 'admin'
        },
        {
            userId: 2,
            username: 'guest',
            password: 'guest'
        }
    ];

    async findOne(username: string): Promise<UserAuthen | undefined> {
        return this.users.find(user => user.username == username);
    }
}
