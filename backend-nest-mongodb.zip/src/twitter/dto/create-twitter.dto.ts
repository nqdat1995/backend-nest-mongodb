export class CreateTwitterDto {
    id?: string;
    tweet: string;
    img: string;
}

export class TwitterDto {
    id?: string;
    tweet: string;
    img: string;
}